SMĚNY PRO – SESTAVENÍ APK POUZE PŘES MOBIL

Tento projekt obsahuje zdroj aplikace a GitHub Actions workflow, které sestaví APK v cloudu. Není potřeba Android Studio ani počítač.

POSTUP
1. V mobilním Chrome otevři https://github.com a přihlas se / vytvoř účet.
2. Vytvoř nový PUBLIC nebo PRIVATE repository s názvem smeny-pro-android. Při zakládání nezaškrtávej README, .gitignore ani licenci.
3. Nahraj soubory z tohoto ZIPu do repozitáře. Důležité cesty:
   - package.json (kořen repozitáře)
   - capacitor.config.json (kořen repozitáře)
   - www/index.html
   - .github/workflows/build-apk.yml
   Pokud mobilní GitHub neumí nahrát složky, vytvoř přes Add file > Create new file nejprve soubor www/.gitkeep a .github/workflows/.gitkeep; poté v dané složce použij Add file > Upload files.
4. Po nahrání otevři záložku Actions. Povol GitHub Actions, pokud se zobrazí výzva.
5. Vyber workflow Build Směny PRO APK a klepni na Run workflow.
6. Počkej, až běh skončí zelenou fajfkou. Otevři konkrétní běh a dole v části Artifacts stáhni smeny-pro-debug-apk.
7. Rozbal stažený ZIP a otevři app-debug.apk. Android může požádat o povolení instalace aplikací z tohoto zdroje.

POZNÁMKY
- Jde o testovací/debug APK, ne podepsanou produkční distribuci do Google Play.
- Artifact na GitHubu má nastavenou dobu uchování 14 dní; po stažení si APK bezpečně ulož.
- Aplikace uchovává data lokálně v zařízení. Neexistuje zatím cloudová synchronizace.
- Nikdy do veřejného repozitáře nevkládej osobní údaje zaměstnanců. Zdrojový kód samotný je v pořádku.
